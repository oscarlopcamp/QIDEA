# This code is part of Qiskit.
#
# (C) Copyright IBM 2017, 2021.
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at https://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

"""
=======================================
DAG Circuits (:mod:`qiskit.dagcircuit`)
=======================================

.. currentmodule:: qiskit.dagcircuit

Circuits as Directed Acyclic Graphs
===================================

.. autosummary::
   :toctree: ../stubs/

   DAGCircuit
   DAGNode
   DAGOpNode
   DAGInNode
   DAGOutNode
   DAGDepNode
   DAGDependency

Exceptions
==========

.. autoexception:: DAGCircuitError
.. autoexception:: DAGDependencyError

Utilities
=========

.. autosummary::
   :toctree: ../stubs/

   BlockCollapser
   BlockCollector
   BlockSplitter
"""
from .collect_blocks import BlockCollapser, BlockCollector, BlockSplitter
from .dagcircuit import DAGCircuit
from .dagnode import DAGNode, DAGOpNode, DAGInNode, DAGOutNode
from .dagdepnode import DAGDepNode
from .exceptions import DAGCircuitError, DAGDependencyError
from .dagdependency import DAGDependency

__all__ = [
    "BlockCollapser",
    "BlockCollector",
    "BlockSplitter",
    "DAGCircuit",
    "DAGCircuitError",
    "DAGDepNode",
    "DAGDependency",
    "DAGDependencyError",
    "DAGInNode",
    "DAGNode",
    "DAGOpNode",
    "DAGOutNode",
]
